package com.example.oponemohamedazizzaghdoudi

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.content.ContextCompat
import com.example.oponemohamedazizzaghdoudi.database.DatabaseHelper
import java.util.*
import android.Manifest
import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts
import android.graphics.Color
import android.view.Gravity
import android.view.ViewGroup
import android.graphics.Typeface

class InventoryActivity : ComponentActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private val SMS_PERMISSION_CODE = 101

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_inventory)

        dbHelper = DatabaseHelper(this)

        val inventoryList = findViewById<GridLayout>(R.id.inventory_grid)
        val searchItemIdInput = findViewById<EditText>(R.id.search_item_id)
        val searchButton = findViewById<Button>(R.id.search_button)
        val filterDateButton = findViewById<Button>(R.id.filter_date_button)
        val filterDateDisplay = findViewById<TextView>(R.id.filter_date_display)
        val logoutButton = findViewById<Button>(R.id.logout_button)
        val dateDisplay = findViewById<TextView>(R.id.add_item_date_display)

        val addItemButton = findViewById<Button>(R.id.add_item_button)
        val itemNameInput = findViewById<EditText>(R.id.item_name)
        val itemQuantityInput = findViewById<EditText>(R.id.item_quantity) // Assuming date picker updates this

        addItemButton.setOnClickListener {
            val name = itemNameInput.text.toString().trim()
            val quantityText = itemQuantityInput.text.toString().trim()
            val date = dateDisplay.text.toString().trim()

            if (name.isEmpty() || quantityText.isEmpty() || date.isEmpty() || date == "Select a date") {
                Toast.makeText(this, "All fields are required!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val quantity = quantityText.toIntOrNull()
            if (quantity == null || quantity <= 0) {
                Toast.makeText(this, "Quantity must be a valid number!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ✅ Remove "Selected Date:" if it exists
            val cleanDate = date.replace("Selected Date:", "").trim()

            val success = dbHelper.addItem(name, quantity, cleanDate) // ✅ Save only the correct date
            if (success) {
                Toast.makeText(this, "Item Added Successfully!", Toast.LENGTH_SHORT).show()
                itemNameInput.text.clear()
                itemQuantityInput.text.clear()
                dateDisplay.text = "Select a date" // Reset date picker text
                loadInventory(findViewById(R.id.inventory_grid)) // Refresh inventory display
            } else {
                Toast.makeText(this, "Failed to add item!", Toast.LENGTH_SHORT).show()
            }
        }



        // 🟢 Load All Inventory Items
        loadInventory(inventoryList)

        // 🟢 Toggle Search Input Visibility when "🔍" is clicked
        searchButton.setOnClickListener {
            if (searchItemIdInput.visibility == View.GONE) {
                searchItemIdInput.visibility = View.VISIBLE
            } else {
                searchItemIdInput.visibility = View.GONE
            }
        }
        logoutButton.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK // Clears back stack
            startActivity(intent)
            finish() // Ends current activity to prevent going back
        }



        // 🟢 Search for an Item by ID
        searchItemIdInput.setOnEditorActionListener { _, _, _ ->
            val itemId = searchItemIdInput.text.toString().trim()

            if (itemId.isEmpty()) {
                // If search field is empty, reload full inventory
                loadInventory(inventoryList)
            } else {
                val item = dbHelper.getItemById(itemId.toIntOrNull() ?: -1)

                inventoryList.removeAllViews() // Clear previous results
                addHeaderRow(inventoryList) // Ensure headers are re-added

                if (item != null) {
                    val (id, name, quantity, date) = item

                    // Create TextViews for each column entry
                    val idTextView = createGridTextView(id.toString())
                    val nameTextView = createGridTextView(name)
                    val quantityTextView = createGridTextView(quantity.toString())
                    val dateTextView = createGridTextView(date)

                    // Highlight Low Stock in Red
                    if (quantity < 5) {
                        quantityTextView.setTextColor(Color.RED)
                    }

                    // Click to Edit Item
                    nameTextView.setOnClickListener {
                        showEditDialog(id, name, quantity, date)
                    }

                    // Long Press to Delete Item
                    nameTextView.setOnLongClickListener {
                        showDeleteConfirmation(id)
                        true
                    }

                    // Add TextViews to GridLayout
                    inventoryList.addView(idTextView)
                    inventoryList.addView(nameTextView)
                    inventoryList.addView(quantityTextView)
                    inventoryList.addView(dateTextView)
                } else {
                    // If no item is found, show "ITEM NOT FOUND"
                    val notFoundTextView = createGridTextView("ITEM NOT FOUND")
                    notFoundTextView.setTextColor(Color.RED)
                    notFoundTextView.gravity = Gravity.CENTER
                    inventoryList.addView(notFoundTextView)
                }
            }
            true
        }


        // 🟢 Open Date Picker When TextView is Clicked
        dateDisplay.setOnClickListener {
            showDatePicker(dateDisplay,inventoryList)
        }
        // 🟢 Show Date Picker when "📅" is clicked
        filterDateButton.setOnClickListener {
            showDatePicker(filterDateDisplay, inventoryList)
        }

        // Check if SMS permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            showSMSPermissionDialog()
        }
    }

    // 🟢 Load Inventory Items into GridLayout
    private fun loadInventory(inventoryGrid: GridLayout) {
        inventoryGrid.removeAllViews() // Clear previous views

        val items = dbHelper.getAllItems()
        inventoryGrid.columnCount = 4 // Ensuring 4 columns for the grid

        // 🟢 Add Header Row (Only Once)
        addHeaderRow(inventoryGrid)

        // 🟢 Populate Data from Database
        for ((id, name, quantity, date) in items) {
            val idTextView = createGridTextView(id.toString())
            val nameTextView = createGridTextView(name)
            val quantityTextView = createGridTextView(quantity.toString())
            val dateTextView = createGridTextView(date)

            // 🟢 Highlight Low-Stock Items in Red
            if (quantity < 5) {
                quantityTextView.setTextColor(Color.RED)
            }

            // 🟢 Click to Edit Item
            nameTextView.setOnClickListener {
                showEditDialog(id, name, quantity, date)
            }

            // 🟢 Apply Click and Long Click to Entire Row
            val rowViews = listOf(idTextView, nameTextView, quantityTextView, dateTextView)

            for (view in rowViews) {
                view.setOnClickListener {
                    showEditDialog(id, name, quantity, date)
                }
                view.setOnLongClickListener {
                    showDeleteConfirmation(id)
                    true
                }
            }
            // 🟢 Add Views to GridLayout (Each row must have exactly 4 columns)
            inventoryGrid.addView(idTextView)
            inventoryGrid.addView(nameTextView)
            inventoryGrid.addView(quantityTextView)
            inventoryGrid.addView(dateTextView)
        }
    }

    // 🟢 Function to Create a Header Row
    private fun addHeaderRow(inventoryGrid: GridLayout) {
        val headers = listOf("Item ID", "Item Name", "Quantity", "Date")
        for (header in headers) {
            val headerTextView = createGridTextView(header, isHeader = true) // Mark as header
            inventoryGrid.addView(headerTextView)
        }
    }


    private fun createGridTextView(text: String, isHeader: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            this.textSize = 14f
            this.setPadding(16, 8, 16, 8) // Better padding for readability
            this.gravity = Gravity.CENTER
            this.setTextColor(Color.WHITE) // White text for contrast

            // Different styles for headers and regular rows
            if (isHeader) {
                this.setTypeface(null, Typeface.BOLD)
                this.setBackgroundColor(Color.DKGRAY) // Dark gray background for headers
            } else {
                this.setBackgroundColor(Color.parseColor("white")) // Orange row background
                this.setTextColor(Color.BLACK) // Black text for contrast
            }

            // Apply grid layout params
            this.layoutParams = GridLayout.LayoutParams().apply {
                width = 0
                height = ViewGroup.LayoutParams.WRAP_CONTENT
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f) // Equal spacing
                setMargins(2, 2, 2, 2) // Adds spacing between grid cells
            }
        }
    }







    // 🟢 Show Date Picker and Filter Items by Date
    private fun showDatePicker(dateTextView: TextView, inventoryGrid: GridLayout) {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
            val selectedDate = String.format("%04d-%02d-%02d", selectedYear, selectedMonth + 1, selectedDay)

            //  Store only the date (No "Selected Date:" prefix)
            dateTextView.text = selectedDate
            dateTextView.visibility = View.VISIBLE // Show selected date

            //  Clear previous results and re-add headers
            inventoryGrid.removeAllViews()
            addHeaderRow(inventoryGrid) //  Maintain headers for a structured view

            // 🟢 Fetch items matching the selected date
            val filteredItems = dbHelper.getItemsByDate(selectedDate)

            if (filteredItems.isEmpty()) {
                val noItemsTextView = createGridTextView("No items found for this date.")
                noItemsTextView.setTextColor(Color.RED)
                noItemsTextView.gravity = Gravity.CENTER
                inventoryGrid.addView(noItemsTextView)
            } else {
                for (item in filteredItems) {
                    val id = item[0] as Int
                    val name = item[1] as String
                    val quantity = item[2] as Int
                    val date = item[3] as String

                    val idTextView = createGridTextView(id.toString())
                    val nameTextView = createGridTextView(name)
                    val quantityTextView = createGridTextView(quantity.toString())
                    val dateTextView = createGridTextView(date)

                    // Highlight Low-Stock Items in Red
                    if (quantity < 5) {
                        quantityTextView.setTextColor(Color.RED)
                    }

                    // Click to Edit Item
                    nameTextView.setOnClickListener {
                        showEditDialog(id, name, quantity, date)
                    }

                    // Long Press to Delete Item
                    nameTextView.setOnLongClickListener {
                        showDeleteConfirmation(id)
                        true
                    }

                    // Add items in the correct grid format
                    inventoryGrid.addView(idTextView)
                    inventoryGrid.addView(nameTextView)
                    inventoryGrid.addView(quantityTextView)
                    inventoryGrid.addView(dateTextView)
                }
            }
        }, year, month, day)

        datePickerDialog.show()
    }


    private fun showEditDialog(itemId: Int, currentName: String, currentQuantity: Int, currentDate: String) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_edit_item, null)
        val editName = dialogView.findViewById<EditText>(R.id.edit_item_name)
        val editQuantity = dialogView.findViewById<EditText>(R.id.edit_item_quantity)
        val editDate = dialogView.findViewById<TextView>(R.id.edit_item_date)
        val inventoryGrid = findViewById<GridLayout>(R.id.inventory_grid)


        editName.setText(currentName)
        editQuantity.setText(currentQuantity.toString())
        editDate.text = currentDate

        // Handle date selection
        editDate.setOnClickListener {
            val calendar = Calendar.getInstance()
            val datePicker = DatePickerDialog(this, { _, year, month, day ->
                editDate.text = "$year-${month + 1}-$day"
            }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
            datePicker.show()
        }

        // Show AlertDialog
        AlertDialog.Builder(this)
            .setTitle("Edit Item")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                val newName = editName.text.toString()
                val newQuantity = editQuantity.text.toString().toIntOrNull() ?: 0
                val newDate = editDate.text.toString()

                if (dbHelper.updateItem(itemId, newName, newQuantity, newDate)) {
                    Toast.makeText(this, "Item updated!", Toast.LENGTH_SHORT).show()
                    loadInventory(inventoryGrid) //  Correct - Pass the actual GridLayout object) // Refresh list
                } else {
                    Toast.makeText(this, "Update failed!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    private fun showDeleteConfirmation(itemId: Int) {
        AlertDialog.Builder(this)
            .setTitle("Delete Item")
            .setMessage("Are you sure you want to delete this item?")
            .setPositiveButton("Delete") { _, _ ->
                if (dbHelper.deleteItem(itemId)) {
                    Toast.makeText(this, "Item deleted!", Toast.LENGTH_SHORT).show()
                    loadInventory(findViewById(R.id.inventory_grid)) // Refresh the list
                } else {
                    Toast.makeText(this, "Failed to delete item.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    private fun showSMSPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("Enable SMS Notifications?")
            .setMessage("Would you like to receive SMS alerts when an inventory item is low on stock?")
            .setPositiveButton("Yes") { _, _ ->
                requestSMSPermissionLauncher.launch(Manifest.permission.SEND_SMS)
            }
            .setNegativeButton("No") { _, _ ->
                Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show()
            }
            .show()
    }
    private val requestSMSPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted ->
            if (isGranted) {
                Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show()
            }
        }


}


