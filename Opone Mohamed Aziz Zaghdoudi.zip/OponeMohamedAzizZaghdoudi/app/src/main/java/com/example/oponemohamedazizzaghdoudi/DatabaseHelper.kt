package com.example.oponemohamedazizzaghdoudi.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import java.util.Date
import java.util.Locale

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    override fun onCreate(db: SQLiteDatabase) {
        Log.d("DatabaseHelper", "Creating database...")

        val createUserTable = """
        CREATE TABLE IF NOT EXISTS $TABLE_USERS (
            $COL_USER_ID INTEGER PRIMARY KEY AUTOINCREMENT, 
            $COL_USERNAME TEXT UNIQUE, 
            $COL_PASSWORD TEXT
        )
    """.trimIndent()

        val createInventoryTable = """
        CREATE TABLE IF NOT EXISTS $TABLE_INVENTORY (
            $COL_ITEM_ID INTEGER PRIMARY KEY AUTOINCREMENT, 
            $COL_ITEM_NAME TEXT, 
            $COL_ITEM_QUANTITY INTEGER,
            $COL_ITEM_DATE TEXT
        )
    """.trimIndent()

        db.execSQL(createUserTable)
        Log.d("DatabaseHelper", "User table created successfully!")

        db.execSQL(createInventoryTable)
        Log.d("DatabaseHelper", "Inventory table created successfully!")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_USERS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_INVENTORY")
        onCreate(db)
    }

    // 🟢 Register User
    fun registerUser(username: String, password: String): Boolean {
        val db = writableDatabase

        // 🔍 Check if username already exists
        val cursor = db.rawQuery("SELECT * FROM $TABLE_USERS WHERE $COL_USERNAME = ?", arrayOf(username))
        val userExists = cursor.count > 0
        cursor.close()

        if (userExists) {
            Log.e("DatabaseHelper", "Error: Username already exists!")
            return false  //  Prevent duplicate registration
        }

        // ✅ Insert new user if username is unique
        val values = ContentValues().apply {
            put(COL_USERNAME, username)
            put(COL_PASSWORD, password)
        }
        val result = db.insert(TABLE_USERS, null, values)
        db.close()

        return result != -1L  // Return true if insertion is successful
    }


    // 🟢 Authenticate Login
    fun checkUser(username: String, password: String): Boolean {
        val db = readableDatabase
        val query = "SELECT * FROM $TABLE_USERS WHERE $COL_USERNAME = ? AND $COL_PASSWORD = ?"
        val cursor = db.rawQuery(query, arrayOf(username, password))
        val exists = cursor.count > 0
        cursor.close()
        return exists
    }

    // 🟢 Add Inventory Item
    fun addItem(name: String, quantity: Int, date: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COL_ITEM_NAME, name)
        values.put(COL_ITEM_QUANTITY, quantity)
        values.put(COL_ITEM_DATE, date)

        val result = db.insert(TABLE_INVENTORY, null, values)
        db.close() // Close database to avoid leaks
        return result != -1L
    }

    // 🟢 Get All Inventory Items
    fun getAllItems(): List<InventoryItem> {
        val db = readableDatabase
        val list = mutableListOf<InventoryItem>()
        val cursor = db.rawQuery("SELECT * FROM $TABLE_INVENTORY", null)

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID))
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME))
                val quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY))
                val date = formatDate(cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_DATE))) // ✅ Format date here

                list.add(InventoryItem(id, name, quantity, date))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }
    // 🟢 Search Item by ID
    fun getItemById(itemId: Int): InventoryItem? {
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM $TABLE_INVENTORY WHERE $COL_ITEM_ID = ?", arrayOf(itemId.toString()))

        var item: InventoryItem? = null
        if (cursor.moveToFirst()) {
            val id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID))
            val name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME))
            val quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY))
            val date = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_DATE))

            item = InventoryItem(id, name, quantity, date) // ✅ Return an `InventoryItem` object
        }
        cursor.close()
        return item
    }



    fun getItemsByDate(date: String): List<List<Any>> {
        val db = readableDatabase
        val list = mutableListOf<List<Any>>()  // ✅ Use List<List<Any>> instead of Triple or Quadruple
        val cursor = db.rawQuery("SELECT * FROM $TABLE_INVENTORY WHERE $COL_ITEM_DATE = ?", arrayOf(date))

        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID))
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME))
                val quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY))
                val itemDate = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_DATE))

                list.add(listOf(id, name, quantity, itemDate)) // ✅ Store all values as a list
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }


    // 🟢 Update Inventory Item
    fun updateItem(itemId: Int, newName: String, newQuantity: Int, newDate: String): Boolean {
        val db = writableDatabase
        val values = ContentValues()
        values.put(COL_ITEM_NAME, newName)
        values.put(COL_ITEM_QUANTITY, newQuantity)
        values.put(COL_ITEM_DATE, newDate)

        val result = db.update(TABLE_INVENTORY, values, "$COL_ITEM_ID = ?", arrayOf(itemId.toString()))
        return result > 0
    }

    // 🟢 Get Low-Stock Items (Quantity < 5)
    fun getLowStockItems(): List<Triple<Int, String, Int>> {
        val db = readableDatabase
        val list = mutableListOf<Triple<Int, String, Int>>()
        val cursor = db.rawQuery("SELECT * FROM $TABLE_INVENTORY WHERE $COL_ITEM_QUANTITY < 5", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_ID))
                val name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME))
                val quantity = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY))
                list.add(Triple(id, name, quantity))
            } while (cursor.moveToNext())
        }
        cursor.close()
        return list
    }


    // 🟢 Delete Inventory Item
    fun deleteItem(itemId: Int): Boolean {
        val db = writableDatabase
        val result = db.delete(TABLE_INVENTORY, "$COL_ITEM_ID = ?", arrayOf(itemId.toString()))
        return result > 0
    }

    companion object {
        private const val DATABASE_NAME = "InventoryDB"
        private const val DATABASE_VERSION = 1

        // User Table
        private const val TABLE_USERS = "users"
        private const val COL_USER_ID = "id"
        private const val COL_USERNAME = "username"
        private const val COL_PASSWORD = "password"

        // Inventory Table
        private const val TABLE_INVENTORY = "inventory"
        private const val COL_ITEM_ID = "item_id"
        private const val COL_ITEM_NAME = "item_name"
        private const val COL_ITEM_QUANTITY = "item_quantity"
        private const val COL_ITEM_DATE = "item_date"
    }
}
private fun formatDate(rawDate: String): String {
    return try {
        val inputFormat = java.text.SimpleDateFormat("yyyy-M-d", Locale.getDefault()) // Handles flexible inputs
        val outputFormat = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()) // Ensures fixed YYYY-MM-DD format
        val date = inputFormat.parse(rawDate)
        outputFormat.format(date ?: Date()) // Fallback to current date if parsing fails
    } catch (e: Exception) {
        rawDate // Return original if an error occurs
    }
}
data class InventoryItem(
    val id: Int,
    val name: String,
    val quantity: Int,
    val date: String
)

